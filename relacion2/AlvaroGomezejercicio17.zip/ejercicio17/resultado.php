<?php

        $dividendo = $_GET['dividendo'];
        $divisor = $_GET['divisor'];
        $cociente = $_GET['cociente'];
        $resto = $_GET['resto'];
        $cociente = 0;
        
        while ($dividendo >= $divisor)
        {
            $dividendo -= $divisor;
            $cociente++;
        }

        echo "El cociente es: $cociente y el resto $dividendo ";
    ?>